import { useReducedMotion } from "framer-motion";
import { Fragment, useEffect, useState } from "react";

const pipeline = ["Python", "LLMs", "RAG", "AI Agents", "React", "Node.js", "AWS"];

export default function Terminal() {
  const reduce = useReducedMotion();
  const [active, setActive] = useState(reduce ? pipeline.length - 1 : 0);

  useEffect(() => {
    if (reduce) return;
    const id = window.setInterval(() => setActive((a) => (a + 1) % (pipeline.length + 2)), 900);
    return () => window.clearInterval(id);
  }, [reduce]);

  return (
    <div className="glass overflow-hidden rounded-2xl shadow-glow" aria-label="Technology pipeline">
      <div className="flex items-center gap-2 border-b border-white/[0.07] px-4 py-3">
        <span className="h-2.5 w-2.5 rounded-full bg-white/15" />
        <span className="h-2.5 w-2.5 rounded-full bg-white/15" />
        <span className="h-2.5 w-2.5 rounded-full bg-white/15" />
        <span className="ml-3 font-mono text-xs text-slate-500">stack.pipeline</span>
      </div>
      <div className="space-y-3 px-4 py-4 font-mono text-[13px] leading-relaxed">
        <p className="text-slate-400">
          <span className="text-accent-cyan">$</span> run stack --pipeline
          <span aria-hidden="true" className="ml-1 inline-block h-3.5 w-1.5 translate-y-0.5 bg-slate-300 animate-blink" />
        </p>
        <p className="flex flex-wrap items-center gap-x-1.5 gap-y-2" aria-label={pipeline.join(", then ")}>
          {pipeline.map((step, i) => {
            const lit = i <= active;
            return (
              <Fragment key={step}>
                <span
                  className={`rounded-md border px-2 py-0.5 transition-colors duration-500 ${
                    lit
                      ? "border-accent-violet/40 bg-accent-violet/15 text-violet-100"
                      : "border-white/10 bg-white/[0.02] text-slate-500"
                  }`}
                >
                  {step}
                </span>
                {i < pipeline.length - 1 && (
                  <span aria-hidden="true" className={`transition-colors duration-500 ${lit ? "text-accent-blue" : "text-slate-600"}`}>
                    →
                  </span>
                )}
              </Fragment>
            );
          })}
        </p>
        <p className="text-slate-500">
          <span className="text-emerald-400">✓</span> ready to build
        </p>
      </div>
    </div>
  );
}
