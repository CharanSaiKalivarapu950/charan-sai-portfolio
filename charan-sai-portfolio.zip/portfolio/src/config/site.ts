/**
 * Single source of truth for personal details and links.
 * Edit this file to update the whole site.
 */
export const site = {
  name: "Kalivarapu Charan Sai",
  shortName: "Charan Sai",
  role: "AI & Machine Learning Engineer",
  tagline: "Generative AI Developer",
  location: "Hyderabad, India",
  email: "kalivarapucharan9@gmail.com",
  linkedin: "https://www.linkedin.com/in/charan-kalivarapu-b64ab0349",
  linkedinLabel: "linkedin.com/in/charan-kalivarapu-b64ab0349",

  /**
   * Add your GitHub profile URL here (for example "https://github.com/your-username").
   * While this is empty the GitHub icon shows as "coming soon" instead of linking anywhere.
   */
  github: "",

  /**
   * Drop your resume PDF into /public and keep this path in sync.
   */
  resume: "/Charan-Sai-Resume.pdf",
  resumeFileName: "Kalivarapu-Charan-Sai-Resume.pdf",

  /** Optional endpoint for the contact form (Formspree, Getform, ...). Empty = open email app. */
  formEndpoint: import.meta.env.VITE_FORM_ENDPOINT ?? "",
} as const;

export const navLinks = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "experience", label: "Experience" },
  { id: "skills", label: "Skills" },
  { id: "projects", label: "Projects" },
  { id: "education", label: "Education" },
  { id: "contact", label: "Contact" },
] as const;

export type SectionId = (typeof navLinks)[number]["id"];
