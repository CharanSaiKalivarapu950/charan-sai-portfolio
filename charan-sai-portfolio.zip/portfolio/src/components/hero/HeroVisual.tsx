import { useReducedMotion } from "framer-motion";
import { Bot, Braces, Database, MessagesSquare, Sparkles, User, type LucideIcon } from "lucide-react";
import { useId } from "react";

interface VisualNode {
  id: string;
  label: string;
  x: number;
  y: number;
  icon: LucideIcon;
}

const nodes: VisualNode[] = [
  { id: "llm", label: "LLM", x: 80, y: 78, icon: MessagesSquare },
  { id: "rag", label: "RAG", x: 215, y: 165, icon: Sparkles },
  { id: "agent", label: "AI Agent", x: 370, y: 82, icon: Bot },
  { id: "db", label: "Database", x: 490, y: 190, icon: Database },
  { id: "api", label: "API", x: 345, y: 285, icon: Braces },
  { id: "user", label: "User", x: 175, y: 330, icon: User },
];

const R = 26;

function edgePath(a: VisualNode, b: VisualNode) {
  const mx = (a.x + b.x) / 2;
  const my = (a.y + b.y) / 2;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  // small perpendicular offset for a gentle curve
  const cx = mx - dy * 0.12;
  const cy = my + dx * 0.12;
  return `M ${a.x} ${a.y} Q ${cx} ${cy} ${b.x} ${b.y}`;
}

export default function HeroVisual() {
  const reduce = useReducedMotion();
  const uid = useId().replace(/:/g, "");
  const gradId = `edge-${uid}`;
  const glowId = `glow-${uid}`;

  return (
    <svg
      viewBox="0 0 570 390"
      role="img"
      aria-label="Diagram of an AI system: an LLM connects to retrieval (RAG), an AI agent, a database and an API, which reach the user."
      className="h-auto w-full"
    >
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#5b8cff" />
          <stop offset="1" stopColor="#9b7bff" />
        </linearGradient>
        <radialGradient id={glowId}>
          <stop offset="0" stopColor="#7c8cff" stopOpacity="0.35" />
          <stop offset="1" stopColor="#7c8cff" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* faint cross-links */}
      <path d={edgePath(nodes[1], nodes[3])} stroke="rgba(255,255,255,0.06)" strokeWidth="1" fill="none" strokeDasharray="3 6" />
      <path d={edgePath(nodes[2], nodes[4])} stroke="rgba(255,255,255,0.06)" strokeWidth="1" fill="none" strokeDasharray="3 6" />

      {/* main flow */}
      {nodes.slice(0, -1).map((n, i) => {
        const next = nodes[i + 1];
        const d = edgePath(n, next);
        return (
          <g key={`${n.id}-${next.id}`}>
            <path d={d} stroke={`url(#${gradId})`} strokeOpacity="0.45" strokeWidth="1.5" fill="none" />
            {!reduce && (
              <circle r="3" fill="#bcd0ff">
                <animateMotion dur="3.6s" begin={`${i * 0.7}s`} repeatCount="indefinite" path={d} />
                <animate attributeName="opacity" values="0;1;1;0" dur="3.6s" begin={`${i * 0.7}s`} repeatCount="indefinite" />
              </circle>
            )}
          </g>
        );
      })}

      {/* nodes */}
      {nodes.map((n, i) => {
        const Icon = n.icon;
        return (
          <g key={n.id}>
            <circle cx={n.x} cy={n.y} r={R * 2.2} fill={`url(#${glowId})`} />
            <circle
              cx={n.x}
              cy={n.y}
              r={R}
              fill="#0b0e18"
              stroke={`url(#${gradId})`}
              strokeWidth="1.5"
              className={reduce ? undefined : "animate-floaty"}
              style={reduce ? undefined : { animationDelay: `${i * 0.5}s`, transformOrigin: `${n.x}px ${n.y}px` }}
            />
            <g transform={`translate(${n.x - 11} ${n.y - 11})`} color="#cdd6ff" stroke="currentColor">
              <Icon size={22} strokeWidth={1.6} />
            </g>
            <text
              x={n.x}
              y={n.y + R + 20}
              textAnchor="middle"
              fill="#aab2c8"
              fontSize="13"
              fontFamily="Inter Variable, Inter, system-ui, sans-serif"
            >
              {n.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
