import { motion, useReducedMotion } from "framer-motion";
import { useState } from "react";
import Reveal from "../components/ui/Reveal";
import SectionHeading from "../components/ui/SectionHeading";
import { skillCategories } from "../data/skills";

export default function Skills() {
  const [focus, setFocus] = useState<string>("all");
  const reduce = useReducedMotion();

  return (
    <section id="skills" aria-labelledby="skills-heading" className="section-pad">
      <div className="container-x">
        <SectionHeading
          id="skills-heading"
          title="Skills"
          description="The tools I work with, grouped by what they're used for. Pick a group to bring it forward."
        />

        <Reveal>
          <div role="group" aria-label="Filter skills by category" className="mt-10 flex flex-wrap gap-2">
            {[{ id: "all", title: "All" }, ...skillCategories].map((c) => {
              const on = focus === c.id;
              return (
                <button
                  key={c.id}
                  type="button"
                  aria-pressed={on}
                  onClick={() => setFocus(c.id)}
                  className={`rounded-full border px-4 py-1.5 text-sm transition-colors ${
                    on
                      ? "border-accent-violet/50 bg-accent-violet/15 text-white"
                      : "border-white/10 bg-white/[0.03] text-slate-400 hover:border-white/25 hover:text-white"
                  }`}
                >
                  {c.title}
                </button>
              );
            })}
          </div>
        </Reveal>

        <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {skillCategories.map((cat, i) => {
            const dim = focus !== "all" && focus !== cat.id;
            return (
              <li key={cat.id}>
                <Reveal delay={(i % 3) * 0.05} className="h-full">
                  <div
                    className={`glass h-full rounded-2xl p-5 transition-all duration-300 hover:border-accent-violet/30 ${
                      dim ? "opacity-30" : "opacity-100"
                    } ${focus === cat.id ? "border-accent-violet/40 bg-white/[0.06]" : ""}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-br from-accent-blue/20 to-accent-violet/20 text-violet-200">
                        <cat.icon size={20} aria-hidden="true" />
                      </span>
                      <h3 className="font-display text-base font-medium text-white">{cat.title}</h3>
                    </div>
                    <ul className="mt-5 flex flex-wrap gap-2">
                      {cat.skills.map((s, j) => (
                        <motion.li
                          key={s}
                          initial={reduce ? false : { opacity: 0, scale: 0.92 }}
                          whileInView={{ opacity: 1, scale: 1 }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.3, delay: 0.1 + j * 0.03 }}
                          whileHover={reduce ? undefined : { y: -2 }}
                          className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-medium text-slate-300 transition-colors hover:border-accent-blue/50 hover:bg-accent-blue/10 hover:text-white"
                        >
                          {s}
                        </motion.li>
                      ))}
                    </ul>
                  </div>
                </Reveal>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
