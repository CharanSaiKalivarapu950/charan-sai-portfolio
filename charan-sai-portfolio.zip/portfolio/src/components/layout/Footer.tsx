import { Mail } from "lucide-react";
import { site } from "../../config/site";
import { GithubIcon, LinkedinIcon } from "../ui/BrandIcons";

export default function Footer() {
  return (
    <footer className="border-t border-white/[0.07] px-5 py-10 sm:px-8">
      <div className="container-x flex flex-col items-center justify-between gap-5 text-sm text-slate-500 sm:flex-row">
        <div className="text-center sm:text-left">
          <p className="text-slate-300">© 2026 {site.name}</p>
          <p className="mt-1">Built with React, AI &amp; curiosity.</p>
        </div>
        <div className="flex items-center gap-2">
          <a
            href={site.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn profile (opens in a new tab)"
            className="rounded-full p-2.5 text-slate-400 transition hover:bg-white/10 hover:text-white"
          >
            <LinkedinIcon size={18} />
          </a>
          {site.github ? (
            <a
              href={site.github}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub profile (opens in a new tab)"
              className="rounded-full p-2.5 text-slate-400 transition hover:bg-white/10 hover:text-white"
            >
              <GithubIcon size={18} />
            </a>
          ) : null}
          <a
            href={`mailto:${site.email}`}
            aria-label="Send an email"
            className="rounded-full p-2.5 text-slate-400 transition hover:bg-white/10 hover:text-white"
          >
            <Mail size={18} />
          </a>
        </div>
      </div>
    </footer>
  );
}
