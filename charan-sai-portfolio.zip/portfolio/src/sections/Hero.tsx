import { motion, useReducedMotion } from "framer-motion";
import { ArrowDown, Briefcase, Download, GraduationCap, Mail, MapPin } from "lucide-react";
import HeroVisual from "../components/hero/HeroVisual";
import Terminal from "../components/hero/Terminal";
import { LinkButton } from "../components/ui/Button";
import { GithubIcon, LinkedinIcon } from "../components/ui/BrandIcons";
import { site } from "../config/site";

const iconLink =
  "flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-slate-300 transition hover:-translate-y-0.5 hover:border-white/30 hover:text-white";

export default function Hero() {
  const reduce = useReducedMotion();
  const fade = (delay: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 16 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] as const },
        };

  return (
    <section id="home" aria-labelledby="hero-heading" className="relative flex min-h-screen items-center px-5 pb-16 pt-28 sm:px-8">
      <div className="container-x grid items-center gap-14 lg:grid-cols-[1.05fr_1fr] lg:gap-10">
        <div>
          <motion.h1
            id="hero-heading"
            className="font-display text-4xl font-semibold leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-6xl"
            {...fade(0.1)}
          >
            Hi, I&apos;m {site.shortName}.
          </motion.h1>
          <motion.p className="mt-3 font-display text-xl font-medium text-gradient sm:text-2xl" {...fade(0.2)}>
            {site.role}
          </motion.p>
          <motion.p className="mt-6 max-w-xl text-base leading-relaxed text-slate-400 sm:text-lg" {...fade(0.3)}>
            I build AI-powered applications, intelligent agents, and full-stack systems that turn complex problems into
            practical solutions.
          </motion.p>

          <motion.div className="mt-9 flex flex-wrap gap-3" {...fade(0.4)}>
            <LinkButton href="#projects" variant="primary" icon={<ArrowDown size={16} className="transition group-hover:translate-y-0.5" />}>
              View Projects
            </LinkButton>
            <LinkButton href="#contact" variant="secondary" icon={<Mail size={16} />}>
              Contact Me
            </LinkButton>
            <LinkButton href={site.resume} download={site.resumeFileName} variant="secondary" icon={<Download size={16} />}>
              Download Resume
            </LinkButton>
          </motion.div>

          <motion.div className="mt-8 flex items-center gap-3" {...fade(0.5)}>
            <a href={site.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn profile (opens in a new tab)" className={iconLink}>
              <LinkedinIcon size={18} />
            </a>
            {site.github ? (
              <a href={site.github} target="_blank" rel="noopener noreferrer" aria-label="GitHub profile (opens in a new tab)" className={iconLink}>
                <GithubIcon size={18} />
              </a>
            ) : (
              <span
                role="img"
                aria-label="GitHub profile coming soon"
                title="GitHub profile coming soon"
                className={`${iconLink} cursor-default opacity-40 hover:translate-y-0 hover:border-white/10 hover:text-slate-300`}
              >
                <GithubIcon size={18} />
              </span>
            )}
            <a href={`mailto:${site.email}`} aria-label="Send an email" className={iconLink}>
              <Mail size={18} />
            </a>
          </motion.div>

          <motion.ul className="mt-10 flex flex-col gap-2.5 text-sm text-slate-400" {...fade(0.6)}>
            <li className="flex items-center gap-2.5">
              <Briefcase size={16} className="text-accent-violet" aria-hidden="true" />
              AI Intern at BLIVE, May – July 2026
            </li>
            <li className="flex items-center gap-2.5">
              <GraduationCap size={16} className="text-accent-blue" aria-hidden="true" />
              B.Tech AI &amp; ML, Woxsen University
            </li>
            <li className="flex items-center gap-2.5">
              <MapPin size={16} className="text-accent-cyan" aria-hidden="true" />
              {site.location}
            </li>
          </motion.ul>
        </div>

        <motion.div className="relative" {...fade(0.35)}>
          <HeroVisual />
          <div className="mt-2 sm:ml-10">
            <Terminal />
          </div>
        </motion.div>
      </div>
    </section>
  );
}


