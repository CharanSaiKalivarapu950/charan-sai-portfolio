import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, ArrowUpRight, Clock } from "lucide-react";
import { Fragment, useCallback, useState } from "react";
import { Button, LinkButton } from "../components/ui/Button";
import { GithubIcon } from "../components/ui/BrandIcons";
import Modal from "../components/ui/Modal";
import ProjectArt from "../components/ui/ProjectArt";
import Reveal from "../components/ui/Reveal";
import SectionHeading from "../components/ui/SectionHeading";
import Tag from "../components/ui/Tag";
import { projects, type Project } from "../data/projects";

function GithubAction({ project, className = "" }: { project: Project; className?: string }) {
  if (project.github) {
    return (
      <LinkButton
        href={project.github}
        target="_blank"
        rel="noopener noreferrer"
        variant="secondary"
        className={className}
        icon={<ArrowUpRight size={14} />}
        aria-label={`${project.title} on GitHub (opens in a new tab)`}
      >
        <GithubIcon size={16} />
        GitHub
      </LinkButton>
    );
  }
  return (
    <Button variant="secondary" disabled className={className} title="Code coming soon" aria-label={`${project.title} GitHub repository: coming soon`}>
      <GithubIcon size={16} />
      GitHub
      <Clock size={13} aria-hidden="true" />
    </Button>
  );
}

function MetricTiles({ project }: { project: Project }) {
  if (project.metrics.length === 0) return null;
  return (
    <dl className="grid grid-cols-3 gap-2">
      {project.metrics.map((m) => (
        <div key={m.label} className="rounded-xl border border-white/[0.08] bg-white/[0.03] px-3 py-3">
          <dd className="font-display text-xl font-semibold text-gradient">{m.value}</dd>
          <dt className="mt-1 text-[11px] leading-snug text-slate-400">{m.label}</dt>
        </div>
      ))}
    </dl>
  );
}

function ProjectCard({ project, index, onOpen }: { project: Project; index: number; onOpen: (p: Project) => void }) {
  const reduce = useReducedMotion();
  return (
    <Reveal delay={index * 0.07} className="h-full">
      <motion.article
        whileHover={reduce ? undefined : { y: -6 }}
        transition={{ type: "spring", stiffness: 300, damping: 24 }}
        className="group flex h-full flex-col overflow-hidden rounded-3xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md transition-colors duration-300 hover:border-accent-violet/40 hover:shadow-glow"
      >
        <div className="relative h-44 overflow-hidden border-b border-white/[0.06]">
          <div className="h-full w-full transition-transform duration-500 group-hover:scale-105">
            <ProjectArt kind={project.visual} />
          </div>
        </div>

        <div className="flex flex-1 flex-col p-6">
          <h3 className="font-display text-xl font-semibold leading-snug text-white">{project.title}</h3>
          <p className="mt-1 text-sm text-accent-blue">{project.short}</p>
          <p className="mt-4 text-[15px] leading-relaxed text-slate-400">{project.description}</p>

          <ul className="mt-5 flex flex-wrap gap-2" aria-label="Technologies">
            {project.tech.map((t) => (
              <li key={t}>
                <Tag>{t}</Tag>
              </li>
            ))}
          </ul>

          {project.metrics.length > 0 && (
            <div className="mt-5">
              <MetricTiles project={project} />
            </div>
          )}

          <div className="mt-auto flex flex-wrap gap-3 pt-6">
            <GithubAction project={project} />
            <Button
              variant="primary"
              onClick={() => onOpen(project)}
              aria-label={`View details: ${project.title}`}
              icon={<ArrowRight size={15} />}
            >
              View Details
            </Button>
          </div>
        </div>
      </motion.article>
    </Reveal>
  );
}

function ProjectDetails({ project }: { project: Project }) {
  const steps = [
    { name: "Problem", body: <p>{project.story.problem}</p> },
    { name: "Solution", body: <p>{project.story.solution}</p> },
    {
      name: "Technology",
      body: (
        <ul className="flex flex-wrap gap-2">
          {project.tech.map((t) => (
            <li key={t}>
              <Tag tone="accent">{t}</Tag>
            </li>
          ))}
        </ul>
      ),
    },
    {
      name: "Results",
      body:
        project.metrics.length > 0 ? (
          <ul className="space-y-1.5">
            {project.story.results.map((r) => (
              <li key={r}>{r}</li>
            ))}
          </ul>
        ) : (
          <p>{project.story.results[0]}</p>
        ),
    },
  ];

  return (
    <div>
      <h3 id="project-modal-title" className="pr-12 font-display text-2xl font-semibold text-white sm:text-3xl">
        {project.title}
      </h3>
      <p className="mt-1 text-accent-blue">{project.short}</p>
      <p className="mt-4 leading-relaxed text-slate-300">{project.description}</p>

      <ol className="mt-8 grid gap-3 md:grid-cols-[1fr_auto_1fr_auto_1fr_auto_1fr] md:gap-2">
        {steps.map((s, i) => (
          <Fragment key={s.name}>
            <li className="rounded-2xl border border-white/[0.08] bg-white/[0.03] p-4">
              <h4 className="font-display text-sm font-semibold text-white">{s.name}</h4>
              <div className="mt-2 text-[13px] leading-relaxed text-slate-400">{s.body}</div>
            </li>
            {i < steps.length - 1 && (
              <li aria-hidden="true" className="hidden items-center text-slate-600 md:flex">
                <ArrowRight size={16} />
              </li>
            )}
          </Fragment>
        ))}
      </ol>

      <div className="mt-8 flex flex-wrap gap-3">
        <GithubAction project={project} />
      </div>
    </div>
  );
}

export default function Projects() {
  const [selected, setSelected] = useState<Project | null>(null);
  const close = useCallback(() => setSelected(null), []);

  return (
    <section id="projects" aria-labelledby="projects-heading" className="section-pad">
      <div className="container-x">
        <SectionHeading
          id="projects-heading"
          title="Projects"
          description="A few things I've designed and built, from image classification to real-time traffic optimization."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {projects.map((p, i) => (
            <ProjectCard key={p.id} project={p} index={i} onOpen={setSelected} />
          ))}
        </div>
      </div>

      <Modal open={selected !== null} onClose={close} titleId="project-modal-title">
        {selected && <ProjectDetails project={selected} />}
      </Modal>
    </section>
  );
}
