interface TagProps {
  children: string;
  tone?: "default" | "accent";
  className?: string;
}

export default function Tag({ children, tone = "default", className = "" }: TagProps) {
  const tones = {
    default: "border-white/10 bg-white/[0.04] text-slate-300",
    accent: "border-accent-violet/30 bg-accent-violet/10 text-violet-200",
  };
  return (
    <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium ${tones[tone]} ${className}`}>
      {children}
    </span>
  );
}
