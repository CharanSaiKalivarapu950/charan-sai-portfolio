import { CheckCircle2, Mail, MapPin, Send, TriangleAlert } from "lucide-react";
import { useState, type FormEvent } from "react";
import { Button } from "../components/ui/Button";
import { LinkedinIcon } from "../components/ui/BrandIcons";
import Reveal from "../components/ui/Reveal";
import { site } from "../config/site";

type Status = "idle" | "sending" | "sent" | "error" | "mailto";
type Fields = { name: string; email: string; message: string };
type Errors = Partial<Record<keyof Fields, string>>;

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(f: Fields): Errors {
  const e: Errors = {};
  if (!f.name.trim()) e.name = "Please enter your name.";
  if (!f.email.trim()) e.email = "Please enter your email address.";
  else if (!emailPattern.test(f.email.trim())) e.email = "That email address doesn't look right.";
  if (f.message.trim().length < 10) e.message = "Please write a short message (at least 10 characters).";
  return e;
}

const inputClass =
  "w-full rounded-xl border bg-white/[0.04] px-4 py-3 text-[15px] text-white placeholder:text-slate-500 transition-colors focus:border-accent-violet/60 focus:bg-white/[0.06] focus:outline-none focus-visible:outline-none focus:ring-2 focus:ring-accent-violet/30";

export default function Contact() {
  const [fields, setFields] = useState<Fields>({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<Status>("idle");

  const update = (key: keyof Fields) => (e: { target: { value: string } }) => {
    setFields((f) => ({ ...f, [key]: e.target.value }));
    if (errors[key]) setErrors((er) => ({ ...er, [key]: undefined }));
  };

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const found = validate(fields);
    setErrors(found);
    if (Object.keys(found).length > 0) {
      const first = (["name", "email", "message"] as const).find((k) => found[k]);
      if (first) document.getElementById(`contact-${first}`)?.focus();
      return;
    }

    if (!site.formEndpoint) {
      const subject = encodeURIComponent(`Portfolio message from ${fields.name.trim()}`);
      const body = encodeURIComponent(`${fields.message.trim()}\n\nFrom: ${fields.name.trim()} (${fields.email.trim()})`);
      window.location.href = `mailto:${site.email}?subject=${subject}&body=${body}`;
      setStatus("mailto");
      return;
    }

    setStatus("sending");
    try {
      const res = await fetch(site.formEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ name: fields.name.trim(), email: fields.email.trim(), message: fields.message.trim() }),
      });
      if (!res.ok) throw new Error(String(res.status));
      setStatus("sent");
      setFields({ name: "", email: "", message: "" });
    } catch {
      setStatus("error");
    }
  }

  return (
    <section id="contact" aria-labelledby="contact-heading" className="section-pad">
      <div className="container-x grid gap-14 lg:grid-cols-[1fr_1.1fr] lg:gap-20">
        <Reveal>
          <h2 id="contact-heading" className="font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl lg:text-5xl">
            Let&apos;s build something intelligent.
          </h2>
          <p className="mt-5 max-w-md text-base leading-relaxed text-slate-400 sm:text-lg">
            I&apos;m always interested in AI, Generative AI, and software engineering opportunities.
          </p>

          <ul className="mt-10 space-y-4">
            <li>
              <a href={`mailto:${site.email}`} className="group flex items-center gap-4 text-slate-300 transition hover:text-white">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-accent-blue">
                  <Mail size={19} aria-hidden="true" />
                </span>
                <span>
                  <span className="block text-xs text-slate-500">Email</span>
                  <span className="break-all text-[15px]">{site.email}</span>
                </span>
              </a>
            </li>
            <li className="flex items-center gap-4 text-slate-300">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-accent-cyan">
                <MapPin size={19} aria-hidden="true" />
              </span>
              <span>
                <span className="block text-xs text-slate-500">Location</span>
                <span className="text-[15px]">{site.location}</span>
              </span>
            </li>
            <li>
              <a
                href={site.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-4 text-slate-300 transition hover:text-white"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-accent-violet">
                  <LinkedinIcon size={18} />
                </span>
                <span>
                  <span className="block text-xs text-slate-500">LinkedIn</span>
                  <span className="break-all text-[15px]">
                    {site.linkedinLabel}
                    <span className="sr-only"> (opens in a new tab)</span>
                  </span>
                </span>
              </a>
            </li>
          </ul>
        </Reveal>

        <Reveal delay={0.1}>
          <form onSubmit={onSubmit} noValidate className="glass rounded-3xl p-6 sm:p-8" aria-label="Contact form">
            <div className="space-y-5">
              <div>
                <label htmlFor="contact-name" className="mb-2 block text-sm text-slate-300">
                  Name
                </label>
                <input
                  id="contact-name"
                  name="name"
                  type="text"
                  autoComplete="name"
                  value={fields.name}
                  onChange={update("name")}
                  aria-invalid={errors.name ? true : undefined}
                  aria-describedby={errors.name ? "contact-name-error" : undefined}
                  className={`${inputClass} ${errors.name ? "border-rose-400/60" : "border-white/10"}`}
                  placeholder="Your name"
                />
                {errors.name && (
                  <p id="contact-name-error" className="mt-1.5 text-sm text-rose-300">
                    {errors.name}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="contact-email" className="mb-2 block text-sm text-slate-300">
                  Email
                </label>
                <input
                  id="contact-email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  value={fields.email}
                  onChange={update("email")}
                  aria-invalid={errors.email ? true : undefined}
                  aria-describedby={errors.email ? "contact-email-error" : undefined}
                  className={`${inputClass} ${errors.email ? "border-rose-400/60" : "border-white/10"}`}
                  placeholder="you@company.com"
                />
                {errors.email && (
                  <p id="contact-email-error" className="mt-1.5 text-sm text-rose-300">
                    {errors.email}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="contact-message" className="mb-2 block text-sm text-slate-300">
                  Message
                </label>
                <textarea
                  id="contact-message"
                  name="message"
                  rows={5}
                  value={fields.message}
                  onChange={update("message")}
                  aria-invalid={errors.message ? true : undefined}
                  aria-describedby={errors.message ? "contact-message-error" : undefined}
                  className={`${inputClass} resize-y ${errors.message ? "border-rose-400/60" : "border-white/10"}`}
                  placeholder="How can I help?"
                />
                {errors.message && (
                  <p id="contact-message-error" className="mt-1.5 text-sm text-rose-300">
                    {errors.message}
                  </p>
                )}
              </div>
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-4">
              <Button type="submit" variant="primary" disabled={status === "sending"} icon={<Send size={15} />}>
                {status === "sending" ? "Sending…" : "Send Message"}
              </Button>

              <div role="status" aria-live="polite" className="text-sm">
                {status === "sent" && (
                  <p className="flex items-center gap-2 text-emerald-300">
                    <CheckCircle2 size={16} aria-hidden="true" /> Message sent. Thanks for reaching out.
                  </p>
                )}
                {status === "mailto" && (
                  <p className="flex items-center gap-2 text-emerald-300">
                    <CheckCircle2 size={16} aria-hidden="true" /> Your email app should open with the message ready to send.
                  </p>
                )}
                {status === "error" && (
                  <p className="flex items-center gap-2 text-rose-300">
                    <TriangleAlert size={16} aria-hidden="true" /> Couldn&apos;t send that. Please email me directly at {site.email}.
                  </p>
                )}
              </div>
            </div>
          </form>
        </Reveal>
      </div>
    </section>
  );
}
