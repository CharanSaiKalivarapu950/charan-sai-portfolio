import { useEffect } from "react";
import Footer from "../components/layout/Footer";
import Navbar from "../components/layout/Navbar";
import About from "../sections/About";
import AiLab from "../sections/AiLab";
import Contact from "../sections/Contact";
import Education from "../sections/Education";
import Experience from "../sections/Experience";
import Hero from "../sections/Hero";
import Projects from "../sections/Projects";
import ResumeCta from "../sections/ResumeCta";
import Skills from "../sections/Skills";

export default function Home() {
  useEffect(() => {
    document.title = "Kalivarapu Charan Sai | AI & Machine Learning Engineer";
    // support deep links such as /#projects arriving from the 404 page
    if (window.location.hash) {
      const el = document.getElementById(window.location.hash.slice(1));
      el?.scrollIntoView();
    }
  }, []);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[110] focus:rounded-full focus:bg-white focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-ink-950"
      >
        Skip to content
      </a>
      <Navbar />
      <main id="main">
        <Hero />
        <About />
        <Experience />
        <Skills />
        <Projects />
        <AiLab />
        <Education />
        <ResumeCta />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
