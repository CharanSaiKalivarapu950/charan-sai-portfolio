import Reveal from "./Reveal";

interface SectionHeadingProps {
  id: string;
  title: string;
  description?: string;
  align?: "left" | "center";
}

export default function SectionHeading({ id, title, description, align = "left" }: SectionHeadingProps) {
  return (
    <Reveal className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      <h2 id={id} className="font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl">
        {title}
      </h2>
      {description && <p className="mt-4 text-base leading-relaxed text-slate-400 sm:text-lg">{description}</p>}
    </Reveal>
  );
}
