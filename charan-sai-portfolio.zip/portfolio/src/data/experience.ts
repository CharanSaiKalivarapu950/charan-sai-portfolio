export interface ExperienceWorkstream {
  title: string;
  points: string[];
  tech: string[];
}

export const experience = {
  role: "Artificial Intelligence Intern",
  company: "BLIVE",
  period: "May 2026 – July 2026",
  project: "LLM-Powered Fleet Management Assistant",
  workstreams: [
    {
      title: "LLM-powered fleet management assistant",
      points: [
        "Developed an LLM-powered fleet management assistant using React.js, Node.js, PostgreSQL and REST APIs for natural language querying.",
        "Designed prompt-driven conversational workflows and integrated enterprise data to generate real-time operational insights.",
      ],
      tech: ["React.js", "Node.js", "PostgreSQL", "REST APIs", "Prompt engineering"],
    },
    {
      title: "WhatsApp support assistant",
      points: [
        "Built an intelligent WhatsApp support assistant using Node.js, PostgreSQL, Twilio API and OCR for automated ticket management.",
        "Designed multi-step AI workflows involving GPS location capture, document processing and conversational automation.",
      ],
      tech: ["Node.js", "PostgreSQL", "Twilio API", "OCR"],
    },
  ] satisfies ExperienceWorkstream[],
};
