// Generates public/og-image.png (1200x630) for social link previews.
// Run with: npm run og
import sharp from "sharp";
import { writeFile } from "node:fs/promises";

const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#5b8cff"/><stop offset="1" stop-color="#9b7bff"/>
    </linearGradient>
    <radialGradient id="a" cx="15%" cy="0%" r="60%"><stop offset="0" stop-color="#5b8cff" stop-opacity=".35"/><stop offset="1" stop-color="#5b8cff" stop-opacity="0"/></radialGradient>
    <radialGradient id="b" cx="95%" cy="80%" r="55%"><stop offset="0" stop-color="#9b7bff" stop-opacity=".35"/><stop offset="1" stop-color="#9b7bff" stop-opacity="0"/></radialGradient>
  </defs>
  <rect width="1200" height="630" fill="#05060a"/>
  <rect width="1200" height="630" fill="url(#a)"/>
  <rect width="1200" height="630" fill="url(#b)"/>
  <g stroke="rgba(255,255,255,0.05)">
    ${Array.from({ length: 19 }, (_, i) => `<path d="M${i * 64} 0V630"/>`).join("")}
    ${Array.from({ length: 10 }, (_, i) => `<path d="M0 ${i * 64}H1200"/>`).join("")}
  </g>
  <g stroke="url(#g)" stroke-opacity=".5" stroke-width="2" fill="none">
    <path d="M820 130 L930 210 L1050 120 L1110 230 L1000 330"/>
  </g>
  <g fill="#0b0e18" stroke="url(#g)" stroke-width="2">
    <circle cx="820" cy="130" r="14"/><circle cx="930" cy="210" r="14"/><circle cx="1050" cy="120" r="14"/>
    <circle cx="1110" cy="230" r="14"/><circle cx="1000" cy="330" r="14"/>
  </g>
  <text x="80" y="110" font-family="Helvetica, Arial, sans-serif" font-weight="700" font-size="44" fill="url(#g)">CS.</text>
  <text x="80" y="330" font-family="Helvetica, Arial, sans-serif" font-weight="700" font-size="76" fill="#ffffff">Kalivarapu Charan Sai</text>
  <text x="80" y="405" font-family="Helvetica, Arial, sans-serif" font-weight="500" font-size="38" fill="#aab2c8">AI &amp; Machine Learning Engineer</text>
  <text x="80" y="540" font-family="Helvetica, Arial, sans-serif" font-size="28" fill="#7d859b">LLM applications · AI agents · RAG · Full-stack systems</text>
</svg>`;

const png = await sharp(Buffer.from(svg)).png().toBuffer();
await writeFile(new URL("../public/og-image.png", import.meta.url), png);
console.log("Wrote public/og-image.png");
