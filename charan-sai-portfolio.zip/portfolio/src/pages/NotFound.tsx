import { ArrowLeft } from "lucide-react";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/layout/Navbar";

export default function NotFound() {
  useEffect(() => {
    const previous = document.title;
    document.title = "Page not found | Kalivarapu Charan Sai";
    const meta = document.createElement("meta");
    meta.name = "robots";
    meta.content = "noindex";
    document.head.appendChild(meta);
    return () => {
      document.title = previous;
      meta.remove();
    };
  }, []);

  return (
    <>
      <Navbar isHome={false} />
      <main id="main" className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <p className="font-mono text-sm text-slate-500">HTTP 404</p>
        <h1 className="mt-4 font-display text-6xl font-bold tracking-tight text-gradient sm:text-8xl">404</h1>
        <p className="mt-6 font-display text-2xl font-semibold text-white">This page isn&apos;t in the pipeline.</p>
        <p className="mt-3 max-w-md text-slate-400">
          The link may be broken or the page may have moved. The portfolio home page has everything.
        </p>
        <Link
          to="/"
          className="group mt-9 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-accent-blue to-accent-violet px-6 py-3 text-sm font-medium text-white shadow-[0_8px_30px_-8px_rgba(123,123,255,0.7)] transition hover:-translate-y-0.5"
        >
          <ArrowLeft size={16} aria-hidden="true" />
          Back to home
        </Link>
      </main>
    </>
  );
}
