import { Briefcase, CalendarDays } from "lucide-react";
import Reveal from "../components/ui/Reveal";
import SectionHeading from "../components/ui/SectionHeading";
import Tag from "../components/ui/Tag";
import { experience } from "../data/experience";

export default function Experience() {
  return (
    <section id="experience" aria-labelledby="experience-heading" className="section-pad">
      <div className="container-x">
        <SectionHeading
          id="experience-heading"
          title="Experience"
          description="Where I've built and shipped AI-powered products so far."
        />

        <div className="relative mt-14 pl-7 sm:pl-12">
          {/* timeline rail */}
          <div aria-hidden="true" className="absolute bottom-0 left-[7px] top-2 w-px bg-gradient-to-b from-accent-violet via-accent-blue/40 to-transparent sm:left-[15px]" />
          <div aria-hidden="true" className="absolute left-0 top-2 h-[15px] w-[15px] rounded-full border-2 border-accent-violet bg-ink-950 shadow-[0_0_18px_rgba(155,123,255,0.8)] sm:left-2" />

          <Reveal>
            <article className="relative overflow-hidden rounded-3xl border border-accent-violet/25 bg-gradient-to-br from-white/[0.06] to-white/[0.015] p-6 shadow-glow backdrop-blur-md sm:p-9">
              <div aria-hidden="true" className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-accent-violet/20 blur-[90px]" />

              <header className="relative flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p className="flex items-center gap-2 text-sm text-slate-400">
                    <Briefcase size={16} className="text-accent-violet" aria-hidden="true" />
                    {experience.company}
                  </p>
                  <h3 className="mt-2 font-display text-2xl font-semibold text-white sm:text-3xl">{experience.role}</h3>
                  <p className="mt-2 text-base text-slate-300">{experience.project}</p>
                </div>
                <p className="inline-flex w-fit items-center gap-2 rounded-full border border-white/10 bg-white/[0.05] px-4 py-2 text-sm text-slate-200">
                  <CalendarDays size={15} className="text-accent-blue" aria-hidden="true" />
                  {experience.period}
                </p>
              </header>

              <div className="relative mt-8 grid gap-5 md:grid-cols-2">
                {experience.workstreams.map((w) => (
                  <div key={w.title} className="rounded-2xl border border-white/[0.08] bg-ink-950/50 p-5 sm:p-6">
                    <h4 className="font-display text-lg font-medium text-white">{w.title}</h4>
                    <ul className="mt-4 space-y-3 text-[15px] leading-relaxed text-slate-300">
                      {w.points.map((pt) => (
                        <li key={pt} className="flex gap-3">
                          <span aria-hidden="true" className="mt-[0.6em] h-1.5 w-1.5 shrink-0 rounded-full bg-accent-blue" />
                          <span>{pt}</span>
                        </li>
                      ))}
                    </ul>
                    <ul className="mt-5 flex flex-wrap gap-2" aria-label={`Technologies used: ${w.title}`}>
                      {w.tech.map((t) => (
                        <li key={t}>
                          <Tag tone="accent">{t}</Tag>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </article>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
