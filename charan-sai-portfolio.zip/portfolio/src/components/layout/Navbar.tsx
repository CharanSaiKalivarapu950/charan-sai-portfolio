import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { navLinks } from "../../config/site";
import { useActiveSection } from "../../hooks/useActiveSection";

const ids = navLinks.map((l) => l.id);

interface NavbarProps {
  /** On non-home routes, links point back to the home page. */
  isHome?: boolean;
}

export default function Navbar({ isHome = true }: NavbarProps) {
  const active = useActiveSection(ids);
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const toggleRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  const href = (id: string) => (isHome ? `#${id}` : `/#${id}`);
  const current = isHome ? active : "";

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled || open ? "border-b border-white/[0.07] bg-ink-950/75 backdrop-blur-xl" : "border-b border-transparent"
      }`}
    >
      <nav aria-label="Primary" className="container-x flex h-16 items-center justify-between px-5 sm:px-8">
        <a
          href={href("home")}
          aria-label="Charan Sai, back to top"
          className="font-display text-xl font-bold tracking-tight text-white"
        >
          CS<span className="text-gradient">.</span>
        </a>

        <ul className="hidden items-center gap-1 lg:flex">
          {navLinks.map((l) => {
            const isActive = current === l.id;
            return (
              <li key={l.id}>
                <a
                  href={href(l.id)}
                  aria-current={isActive ? "true" : undefined}
                  className={`relative rounded-full px-3.5 py-2 text-sm transition-colors ${
                    isActive ? "text-white" : "text-slate-400 hover:text-white"
                  }`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="nav-active"
                      className="absolute inset-0 -z-10 rounded-full border border-white/10 bg-white/[0.07]"
                      transition={{ type: "spring", stiffness: 380, damping: 32 }}
                    />
                  )}
                  {l.label}
                </a>
              </li>
            );
          })}
        </ul>

        <div className="flex items-center gap-3">
          <a
            href={href("contact")}
            className="hidden rounded-full bg-white px-4 py-2 text-sm font-semibold text-ink-950 transition hover:bg-slate-200 sm:inline-flex"
          >
            Let&apos;s Talk
          </a>
          <button
            ref={toggleRef}
            type="button"
            className="rounded-full border border-white/10 p-2 text-slate-200 transition hover:bg-white/10 lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((o) => !o)}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.22 }}
            className="overflow-hidden lg:hidden"
          >
            <ul className="container-x flex flex-col gap-1 px-5 pb-6 pt-2 sm:px-8">
              {navLinks.map((l) => (
                <li key={l.id}>
                  <a
                    href={href(l.id)}
                    onClick={() => setOpen(false)}
                    aria-current={current === l.id ? "true" : undefined}
                    className={`block rounded-xl px-4 py-3 text-base ${
                      current === l.id ? "bg-white/[0.07] text-white" : "text-slate-300 hover:bg-white/[0.05]"
                    }`}
                  >
                    {l.label}
                  </a>
                </li>
              ))}
              <li className="pt-2">
                <a
                  href={href("contact")}
                  onClick={() => setOpen(false)}
                  className="block rounded-xl bg-white px-4 py-3 text-center text-base font-semibold text-ink-950"
                >
                  Let&apos;s Talk
                </a>
              </li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

