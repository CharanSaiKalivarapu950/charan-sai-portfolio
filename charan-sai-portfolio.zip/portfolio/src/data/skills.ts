import {
  Bot,
  BrainCircuit,
  Cloud,
  Code2,
  Container,
  Database,
  Globe,
  Sparkles,
  Wrench,
  type LucideIcon,
} from "lucide-react";

export interface SkillCategory {
  id: string;
  title: string;
  icon: LucideIcon;
  skills: string[];
}

export const skillCategories: SkillCategory[] = [
  { id: "programming", title: "Programming", icon: Code2, skills: ["Python", "JavaScript", "SQL", "C"] },
  {
    id: "genai",
    title: "Generative AI",
    icon: Sparkles,
    skills: ["LLMs", "RAG", "Prompt Engineering", "Embeddings", "AI Agents", "Multi-Agent Systems"],
  },
  { id: "agentic", title: "Agentic AI", icon: Bot, skills: ["LangGraph", "MCP", "Strands AI"] },
  {
    id: "ml",
    title: "AI / ML",
    icon: BrainCircuit,
    skills: ["TensorFlow", "Scikit-learn", "NLP", "Computer Vision", "Regression", "Classification", "Clustering"],
  },
  {
    id: "web",
    title: "Web Development",
    icon: Globe,
    skills: ["React.js", "Node.js", "Express.js", "Flask", "REST APIs", "HTML5", "CSS3"],
  },
  {
    id: "cloud",
    title: "Cloud",
    icon: Cloud,
    skills: ["AWS Lambda", "EC2", "S3", "RDS", "VPC", "CloudWatch", "Bedrock"],
  },
  {
    id: "devops",
    title: "DevOps",
    icon: Container,
    skills: ["Docker", "Git", "GitHub", "CI/CD", "Kubernetes"],
  },
  {
    id: "databases",
    title: "Databases",
    icon: Database,
    skills: ["PostgreSQL", "MySQL", "SQLite", "Vector Databases"],
  },
  { id: "tools", title: "Tools", icon: Wrench, skills: ["VS Code", "Jupyter Notebook"] },
];
