import type { AnchorHTMLAttributes, ButtonHTMLAttributes, ReactNode } from "react";

type Variant = "primary" | "secondary" | "ghost";

const base =
  "group inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium transition-all duration-200 focus-visible:outline-offset-4 disabled:cursor-not-allowed disabled:opacity-50";

const variants: Record<Variant, string> = {
  primary:
    "bg-gradient-to-r from-accent-blue to-accent-violet text-white shadow-[0_8px_30px_-8px_rgba(123,123,255,0.7)] hover:-translate-y-0.5 hover:shadow-[0_12px_36px_-8px_rgba(123,123,255,0.9)]",
  secondary:
    "border border-white/15 bg-white/[0.04] text-slate-100 hover:-translate-y-0.5 hover:border-white/30 hover:bg-white/[0.08]",
  ghost: "text-slate-300 hover:text-white",
};

type CommonProps = { variant?: Variant; icon?: ReactNode; children: ReactNode; className?: string };

export function LinkButton({
  variant = "secondary",
  icon,
  children,
  className = "",
  ...rest
}: CommonProps & AnchorHTMLAttributes<HTMLAnchorElement>) {
  return (
    <a className={`${base} ${variants[variant]} ${className}`} {...rest}>
      {children}
      {icon}
    </a>
  );
}

export function Button({
  variant = "secondary",
  icon,
  children,
  className = "",
  ...rest
}: CommonProps & ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button className={`${base} ${variants[variant]} ${className}`} {...rest}>
      {children}
      {icon}
    </button>
  );
}
