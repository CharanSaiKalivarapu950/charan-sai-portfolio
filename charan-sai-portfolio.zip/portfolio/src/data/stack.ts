import {
  Bot,
  BrainCircuit,
  Cloud,
  Code2,
  Layers,
  MessagesSquare,
  Network,
  Sparkles,
  type LucideIcon,
} from "lucide-react";

export interface StackNode {
  id: string;
  label: string;
  icon: LucideIcon;
  summary: string;
  tools: string[];
}

export const stack: StackNode[] = [
  {
    id: "python",
    label: "Python",
    icon: Code2,
    summary: "The base layer for the machine learning and backend work.",
    tools: ["Python", "Pandas", "Flask"],
  },
  {
    id: "ml",
    label: "Machine Learning",
    icon: BrainCircuit,
    summary: "Classical models for prediction tasks, such as regression with feature engineering for crop price forecasting.",
    tools: ["Scikit-learn", "Regression", "Classification", "Clustering"],
  },
  {
    id: "dl",
    label: "Deep Learning",
    icon: Network,
    summary: "Convolutional networks for image tasks, including the medical image classification pipeline.",
    tools: ["TensorFlow", "CNN", "Computer Vision", "NLP"],
  },
  {
    id: "llm",
    label: "LLMs",
    icon: MessagesSquare,
    summary: "Prompt-driven conversational workflows, like the fleet management assistant built at BLIVE.",
    tools: ["LLMs", "Prompt Engineering", "Embeddings"],
  },
  {
    id: "rag",
    label: "RAG",
    icon: Sparkles,
    summary: "Grounding model answers in retrieved data using embeddings and vector databases.",
    tools: ["RAG", "Embeddings", "Vector Databases"],
  },
  {
    id: "agents",
    label: "AI Agents",
    icon: Bot,
    summary: "Agent and multi-step workflow design, with agent frameworks I work with.",
    tools: ["AI Agents", "Multi-Agent Systems", "LangGraph", "MCP", "Strands AI"],
  },
  {
    id: "fullstack",
    label: "Full-Stack AI Applications",
    icon: Layers,
    summary: "Putting models behind real products: the fleet assistant and the WhatsApp support assistant at BLIVE.",
    tools: ["React.js", "Node.js", "PostgreSQL", "REST APIs", "Twilio API"],
  },
  {
    id: "aws",
    label: "AWS",
    icon: Cloud,
    summary: "Cloud services for running and hosting AI applications.",
    tools: ["Lambda", "EC2", "S3", "RDS", "VPC", "CloudWatch", "Bedrock"],
  },
];
