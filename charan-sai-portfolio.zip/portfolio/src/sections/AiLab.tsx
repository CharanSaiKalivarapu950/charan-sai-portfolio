import { motion, useReducedMotion, AnimatePresence } from "framer-motion";
import { Fragment, useState } from "react";
import Reveal from "../components/ui/Reveal";
import SectionHeading from "../components/ui/SectionHeading";
import Tag from "../components/ui/Tag";
import { stack } from "../data/stack";

export default function AiLab() {
  const [activeId, setActiveId] = useState(stack[0].id);
  const reduce = useReducedMotion();
  const active = stack.find((s) => s.id === activeId) ?? stack[0];
  const activeIndex = stack.findIndex((s) => s.id === activeId);

  return (
    <section id="ai-lab" aria-labelledby="ai-lab-heading" className="section-pad">
      <div className="container-x">
        <SectionHeading
          id="ai-lab-heading"
          title="AI lab"
          description="How my stack fits together, from the language I start in to where the finished application runs. Select a layer to see what sits in it."
        />

        <div className="mt-14 grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:gap-14">
          <Reveal>
            <ol className="relative mx-auto max-w-md lg:mx-0" aria-label="AI stack, from foundation to deployment">
              {stack.map((node, i) => {
                const on = node.id === activeId;
                const passed = i <= activeIndex;
                return (
                  <Fragment key={node.id}>
                    <li>
                      <button
                        type="button"
                        aria-pressed={on}
                        onClick={() => setActiveId(node.id)}
                        onMouseEnter={() => setActiveId(node.id)}
                        onFocus={() => setActiveId(node.id)}
                        className={`flex w-full items-center gap-4 rounded-2xl border px-4 py-3.5 text-left transition-all duration-300 ${
                          on
                            ? "border-accent-violet/50 bg-accent-violet/10 shadow-glow"
                            : "border-white/[0.08] bg-white/[0.03] hover:border-white/20"
                        }`}
                      >
                        <span
                          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border transition-colors ${
                            on ? "border-accent-violet/60 bg-accent-violet/20 text-white" : "border-white/10 bg-ink-900 text-slate-400"
                          }`}
                        >
                          <node.icon size={19} aria-hidden="true" />
                        </span>
                        <span className={`font-display text-[15px] font-medium ${on ? "text-white" : "text-slate-300"}`}>{node.label}</span>
                      </button>
                    </li>
                    {i < stack.length - 1 && (
                      <li aria-hidden="true" className="relative ml-[35px] h-6 w-px overflow-visible">
                        <div className={`h-full w-px transition-colors duration-300 ${i < activeIndex ? "bg-accent-violet/70" : "bg-white/10"}`} />
                        {!reduce && passed && i < activeIndex && (
                          <span className="animate-travel absolute -left-[2px] top-0 h-[5px] w-[5px] rounded-full bg-accent-cyan shadow-[0_0_8px_#5fd4ff]" />
                        )}
                      </li>
                    )}
                  </Fragment>
                );
              })}
            </ol>
          </Reveal>

          <Reveal delay={0.1} className="lg:sticky lg:top-28 lg:self-start">
            <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.06] to-white/[0.015] p-7 backdrop-blur-md sm:p-9" aria-live="polite">
              <div aria-hidden="true" className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-accent-blue/20 blur-[80px]" />
              <AnimatePresence mode="wait">
                <motion.div
                  key={active.id}
                  initial={reduce ? false : { opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={reduce ? undefined : { opacity: 0, y: -6 }}
                  transition={{ duration: 0.2 }}
                  className="relative"
                >
                  <span className="flex h-14 w-14 items-center justify-center rounded-2xl border border-accent-violet/40 bg-accent-violet/15 text-violet-100">
                    <active.icon size={26} aria-hidden="true" />
                  </span>
                  <h3 className="mt-6 font-display text-2xl font-semibold text-white">{active.label}</h3>
                  <p className="mt-3 max-w-md leading-relaxed text-slate-300">{active.summary}</p>
                  <ul className="mt-6 flex flex-wrap gap-2" aria-label={`Tools in ${active.label}`}>
                    {active.tools.map((t) => (
                      <li key={t}>
                        <Tag tone="accent">{t}</Tag>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              </AnimatePresence>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
