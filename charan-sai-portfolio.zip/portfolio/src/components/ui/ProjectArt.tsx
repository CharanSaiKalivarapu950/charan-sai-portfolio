import { useId } from "react";
import type { ProjectVisual } from "../../data/projects";

/** Abstract, text-free illustrations. They depict the idea of each project and carry no data. */
export default function ProjectArt({ kind }: { kind: ProjectVisual }) {
  const uid = useId().replace(/:/g, "");
  const g = `g-${uid}`;
  const glow = `glow-${uid}`;

  return (
    <svg viewBox="0 0 400 220" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs>
        <linearGradient id={g} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#5b8cff" />
          <stop offset="1" stopColor="#9b7bff" />
        </linearGradient>
        <radialGradient id={glow} cx="50%" cy="50%" r="60%">
          <stop offset="0" stopColor="#7c8cff" stopOpacity="0.28" />
          <stop offset="1" stopColor="#7c8cff" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="400" height="220" fill="#0a0d16" />
      <rect width="400" height="220" fill={`url(#${glow})`} />
      {kind === "medical" && <Medical g={g} />}
      {kind === "traffic" && <Traffic g={g} />}
      {kind === "crop" && <Crop g={g} />}
    </svg>
  );
}

function Medical({ g }: { g: string }) {
  // pseudo-image grid with a highlighted region
  const cells: JSX.Element[] = [];
  for (let r = 0; r < 7; r++) {
    for (let c = 0; c < 7; c++) {
      const dist = Math.hypot(c - 3, r - 3);
      const o = Math.max(0.08, 0.75 - dist * 0.16 + ((r * 7 + c * 13) % 5) * 0.03);
      cells.push(<rect key={`${r}-${c}`} x={40 + c * 16} y={54 + r * 16} width="13" height="13" rx="2" fill="#9db4ff" opacity={o} />);
    }
  }
  return (
    <g>
      <rect x="32" y="46" width="128" height="128" rx="12" fill="none" stroke="rgba(255,255,255,0.12)" />
      {cells}
      <circle cx="104" cy="118" r="20" fill="none" stroke="#5fd4ff" strokeWidth="1.5" strokeDasharray="4 3" />
      {/* feature maps */}
      {[0, 1, 2].map((i) => (
        <rect key={i} x={196 + i * 18} y={70 + i * 10} width="46" height="80" rx="6" fill="rgba(124,140,255,0.10)" stroke={`url(#${g})`} strokeOpacity="0.7" />
      ))}
      <path d="M164 110 H192 M262 110 H290" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" strokeDasharray="3 4" />
      {/* output */}
      <rect x="296" y="86" width="60" height="10" rx="5" fill={`url(#${g})`} />
      <rect x="296" y="112" width="34" height="10" rx="5" fill="rgba(255,255,255,0.18)" />
      <rect x="296" y="138" width="22" height="10" rx="5" fill="rgba(255,255,255,0.10)" />
    </g>
  );
}

function Traffic({ g }: { g: string }) {
  return (
    <g>
      {/* roads */}
      <rect x="0" y="88" width="400" height="44" fill="#131828" />
      <rect x="178" y="0" width="44" height="220" fill="#131828" />
      <path d="M0 110 H178 M222 110 H400" stroke="rgba(255,255,255,0.22)" strokeWidth="1.5" strokeDasharray="10 8" />
      <path d="M200 0 V88 M200 132 V220" stroke="rgba(255,255,255,0.22)" strokeWidth="1.5" strokeDasharray="10 8" />
      {/* vehicles */}
      <rect x="40" y="96" width="30" height="14" rx="4" fill="rgba(255,255,255,0.35)" />
      <rect x="92" y="96" width="30" height="14" rx="4" fill="rgba(255,255,255,0.22)" />
      <rect x="284" y="114" width="30" height="14" rx="4" fill="rgba(255,255,255,0.25)" />
      <rect x="203" y="30" width="14" height="30" rx="4" fill="rgba(255,255,255,0.28)" />
      {/* emergency vehicle with detection box */}
      <rect x="203" y="150" width="14" height="34" rx="4" fill="#ff6b7a" />
      <path d="M196 144 h10 M196 144 v10 M224 144 h-10 M224 144 v10 M196 190 h10 M196 190 v-10 M224 190 h-10 M224 190 v-10" stroke="#5fd4ff" strokeWidth="1.6" fill="none" />
      <circle cx="210" cy="167" r="24" fill="none" stroke="#ff6b7a" strokeOpacity="0.4" className="animate-pulse" />
      {/* signal heads */}
      <g>
        <rect x="148" y="52" width="14" height="34" rx="7" fill="#0b0e18" stroke="rgba(255,255,255,0.2)" />
        <circle cx="155" cy="60" r="3.2" fill="#ff6b7a" opacity="0.4" />
        <circle cx="155" cy="69" r="3.2" fill="#ffd166" opacity="0.25" />
        <circle cx="155" cy="78" r="3.2" fill="#4ade80" />
        <rect x="238" y="134" width="14" height="34" rx="7" fill="#0b0e18" stroke="rgba(255,255,255,0.2)" />
        <circle cx="245" cy="142" r="3.2" fill="#ff6b7a" opacity="0.4" />
        <circle cx="245" cy="151" r="3.2" fill="#ffd166" opacity="0.25" />
        <circle cx="245" cy="160" r="3.2" fill="#4ade80" />
      </g>
      <rect x="0" y="0" width="400" height="220" fill="none" stroke={`url(#${g})`} strokeOpacity="0" />
    </g>
  );
}

function Crop({ g }: { g: string }) {
  return (
    <g>
      {[50, 90, 130, 170].map((y) => (
        <path key={y} d={`M36 ${y} H370`} stroke="rgba(255,255,255,0.06)" />
      ))}
      <path d="M36 32 V180 H370" stroke="rgba(255,255,255,0.2)" fill="none" />
      {/* forecast band */}
      <path d="M232 112 L370 64 L370 122 L232 128 Z" fill="rgba(155,123,255,0.14)" />
      {/* history */}
      <path
        d="M36 150 C60 142 72 120 96 128 S136 96 160 104 S200 84 232 118"
        stroke={`url(#${g})`}
        strokeWidth="2.5"
        fill="none"
        strokeLinecap="round"
      />
      {/* forecast */}
      <path d="M232 118 C270 112 320 90 370 92" stroke="#5fd4ff" strokeWidth="2.5" fill="none" strokeDasharray="6 6" strokeLinecap="round" className="animate-dash" />
      <circle cx="232" cy="118" r="4.5" fill="#0a0d16" stroke="#5fd4ff" strokeWidth="2" />
      {/* volume bars */}
      {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
        <rect key={i} x={44 + i * 32} y={180 - (10 + ((i * 7) % 5) * 5)} width="14" height={10 + ((i * 7) % 5) * 5} rx="3" fill="rgba(124,140,255,0.28)" />
      ))}
    </g>
  );
}
