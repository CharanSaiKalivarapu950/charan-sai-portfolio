export type ProjectVisual = "medical" | "traffic" | "crop";

export interface ProjectMetric {
  value: string;
  label: string;
}

export interface Project {
  id: string;
  title: string;
  short: string;
  description: string;
  tech: string[];
  visual: ProjectVisual;
  metrics: ProjectMetric[];
  /** Repository URL. Leave empty until the repo is public. The UI shows "Code coming soon". */
  github: string;
  story: {
    problem: string;
    solution: string;
    results: string[];
  };
}

export const projects: Project[] = [
  {
    id: "ai-diagnostic",
    title: "AI Diagnostic System",
    short: "Medical image classification",
    description:
      "An end-to-end deep learning pipeline for automated disease detection from medical images, covering preprocessing, model training, evaluation and prediction.",
    tech: ["Python", "TensorFlow", "CNN"],
    visual: "medical",
    metrics: [
      { value: "92%", label: "validation accuracy" },
      { value: "89%", label: "precision" },
      { value: "91%", label: "recall" },
    ],
    github: "",
    story: {
      problem: "Detect disease from medical images automatically, with results that can be measured and repeated.",
      solution:
        "Designed and deployed a deep learning pipeline that takes images from preprocessing through model training and evaluation to prediction, using a convolutional neural network.",
      results: ["92% validation classification accuracy", "89% precision", "91% recall"],
    },
  },
  {
    id: "smart-traffic",
    title: "AI-Driven Smart Traffic Signal System",
    short: "With emergency vehicle priority",
    description:
      "A real-time traffic management system that combines computer vision with multi-sensor inputs to adjust signal timings based on live traffic density.",
    tech: ["Python", "Computer Vision", "IoT"],
    visual: "traffic",
    metrics: [
      { value: "95%", label: "emergency vehicle detection" },
      { value: "40%", label: "faster congestion response" },
      { value: "93%", label: "signal optimization accuracy" },
    ],
    github: "",
    story: {
      problem: "Adjust signal timings to live traffic density, and give priority to emergency vehicles.",
      solution:
        "Designed a real-time system that integrates computer vision with multi-sensor inputs and dynamically optimizes traffic signal timings from live traffic density.",
      results: [
        "95% emergency vehicle detection accuracy",
        "40% reduction in average congestion response time",
        "93% overall signal optimization accuracy",
      ],
    },
  },
  {
    id: "crop-price",
    title: "Crop Price Prediction System",
    short: "Price forecasting from agricultural data",
    description:
      "A machine learning model that predicts crop prices from historical agricultural data, using regression algorithms and feature engineering.",
    tech: ["Python", "Scikit-learn", "Pandas"],
    visual: "crop",
    metrics: [],
    github: "",
    story: {
      problem: "Forecast crop prices from historical agricultural data.",
      solution:
        "Designed a machine learning model for price forecasting, applying regression algorithms and feature engineering to the historical data.",
      results: ["A price forecasting model built on historical agricultural data using regression and engineered features"],
    },
  },
];
