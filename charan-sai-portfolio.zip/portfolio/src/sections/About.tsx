import { Bot, Cloud, Eye, Layers, MessagesSquare, Search, Sparkles, Type, type LucideIcon } from "lucide-react";
import Reveal from "../components/ui/Reveal";
import SectionHeading from "../components/ui/SectionHeading";

interface Highlight {
  title: string;
  note: string;
  icon: LucideIcon;
}

const highlights: Highlight[] = [
  { title: "Generative AI", note: "Prompt-driven workflows and embeddings", icon: Sparkles },
  { title: "LLM applications", note: "Assistants with natural language querying", icon: MessagesSquare },
  { title: "AI agents", note: "LangGraph, MCP and Strands AI", icon: Bot },
  { title: "RAG", note: "Retrieval with embeddings and vector databases", icon: Search },
  { title: "NLP", note: "Language-focused machine learning", icon: Type },
  { title: "Computer vision", note: "Medical imaging and traffic detection projects", icon: Eye },
  { title: "Full-stack development", note: "React.js, Node.js, PostgreSQL, REST APIs", icon: Layers },
  { title: "Cloud and AWS", note: "Lambda, EC2, S3, RDS, Bedrock and more", icon: Cloud },
];

export default function About() {
  return (
    <section id="about" aria-labelledby="about-heading" className="section-pad">
      <div className="container-x">
        <SectionHeading id="about-heading" title="About me" />

        <div className="mt-12 grid gap-12 lg:grid-cols-[1fr_1.25fr] lg:gap-16">
          <Reveal className="space-y-5 text-base leading-[1.8] text-slate-300 sm:text-lg">
            <p>
              I&apos;m an Artificial Intelligence and Machine Learning undergraduate at Woxsen University in Hyderabad,
              and I enjoy taking an AI idea past the notebook stage and turning it into something people can actually
              use.
            </p>
            <p>
              This summer I worked as an AI intern at BLIVE, where I built an LLM-powered fleet management assistant and
              a WhatsApp support assistant. Outside of that, my projects cover medical image classification, smart
              traffic signals and crop price prediction.
            </p>
            <p>
              My interests sit around generative AI, LLM applications, agents and RAG, with NLP and computer vision
              alongside. I build the full-stack pieces around them with React, Node.js and PostgreSQL, and I work with
              AWS on the cloud side.
            </p>
          </Reveal>

          <ul className="grid gap-3 sm:grid-cols-2">
            {highlights.map((h, i) => (
              <li key={h.title}>
                <Reveal delay={i * 0.04} className="h-full">
                  <div className="glass group h-full rounded-2xl p-5 transition-colors duration-200 hover:border-accent-violet/30 hover:bg-white/[0.05]">
                    <h.icon size={20} className="text-accent-violet" aria-hidden="true" />
                    <h3 className="mt-4 font-display text-base font-medium text-white">{h.title}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-slate-400">{h.note}</p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
