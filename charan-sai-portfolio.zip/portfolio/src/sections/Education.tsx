import { GraduationCap } from "lucide-react";
import Reveal from "../components/ui/Reveal";
import SectionHeading from "../components/ui/SectionHeading";

const education = [
  {
    school: "Woxsen University",
    degree: "B.Tech, Artificial Intelligence & Machine Learning",
    period: "2023 – Present",
    place: "Hyderabad, India",
  },
  {
    school: "Narayana College",
    degree: "Intermediate, MPC",
    period: "2021 – 2023",
    place: "",
  },
];

export default function Education() {
  return (
    <section id="education" aria-labelledby="education-heading" className="section-pad">
      <div className="container-x">
        <SectionHeading id="education-heading" title="Education" />

        <ul className="mt-12 grid gap-5 md:grid-cols-2">
          {education.map((e, i) => (
            <li key={e.school}>
              <Reveal delay={i * 0.08} className="h-full">
                <div className="glass h-full rounded-3xl p-7 transition-colors hover:border-accent-violet/30">
                  <div className="flex items-start justify-between gap-4">
                    <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-br from-accent-blue/20 to-accent-violet/20 text-violet-200">
                      <GraduationCap size={21} aria-hidden="true" />
                    </span>
                    <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs text-slate-300">{e.period}</span>
                  </div>
                  <h3 className="mt-6 font-display text-xl font-semibold text-white">{e.school}</h3>
                  <p className="mt-2 text-slate-300">{e.degree}</p>
                  {e.place && <p className="mt-1 text-sm text-slate-500">{e.place}</p>}
                </div>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
