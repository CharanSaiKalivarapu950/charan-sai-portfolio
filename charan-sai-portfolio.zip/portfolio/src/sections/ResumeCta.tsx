import { Download, FileText } from "lucide-react";
import { LinkButton } from "../components/ui/Button";
import Reveal from "../components/ui/Reveal";
import { site } from "../config/site";

export default function ResumeCta() {
  return (
    <section id="resume" aria-labelledby="resume-heading" className="px-5 py-16 sm:px-8 md:py-20">
      <div className="container-x">
        <Reveal>
          <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-accent-blue/[0.12] via-white/[0.03] to-accent-violet/[0.14] px-6 py-12 text-center backdrop-blur-md sm:px-12 sm:py-16">
            <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-0 h-40 w-2/3 -translate-x-1/2 rounded-full bg-accent-violet/20 blur-[90px]" />
            <h2 id="resume-heading" className="relative font-display text-2xl font-semibold text-white sm:text-3xl">
              Want to know more about my work?
            </h2>
            <div className="relative mt-8 flex flex-wrap justify-center gap-3">
              <LinkButton href={site.resume} target="_blank" rel="noopener noreferrer" variant="primary" icon={<FileText size={16} />}>
                View Resume
              </LinkButton>
              <LinkButton href={site.resume} download={site.resumeFileName} variant="secondary" icon={<Download size={16} />}>
                Download Resume
              </LinkButton>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
