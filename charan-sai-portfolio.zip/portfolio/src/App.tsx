import { Route, Routes, useLocation } from "react-router-dom";
import { useEffect } from "react";
import NetworkBackground from "./components/background/NetworkBackground";
import Loader from "./components/layout/Loader";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";

export default function App() {
  const { pathname } = useLocation();

  useEffect(() => {
    if (!window.location.hash) window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <>
      <NetworkBackground />
      <Loader />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}
