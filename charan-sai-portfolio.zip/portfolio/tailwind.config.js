/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          950: "#05060a",
          900: "#080a11",
          800: "#0d1019",
          700: "#141826",
        },
        accent: {
          blue: "#5b8cff",
          violet: "#9b7bff",
          cyan: "#5fd4ff",
        },
      },
      fontFamily: {
        display: ["'Sora Variable'", "Sora", "system-ui", "sans-serif"],
        sans: ["'Inter Variable'", "Inter", "system-ui", "sans-serif"],
        mono: ["'JetBrains Mono Variable'", "'JetBrains Mono'", "ui-monospace", "monospace"],
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(155,123,255,0.25), 0 20px 60px -20px rgba(91,140,255,0.35)",
      },
      keyframes: {
        blink: { "0%,49%": { opacity: "1" }, "50%,100%": { opacity: "0" } },
        floaty: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-6px)" } },
        dash: { to: { strokeDashoffset: "-24" } },
      },
      animation: {
        blink: "blink 1s steps(1) infinite",
        floaty: "floaty 6s ease-in-out infinite",
        dash: "dash 1.6s linear infinite",
      },
    },
  },
  plugins: [],
};
